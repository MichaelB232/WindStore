"use client";

import { toast } from "sonner";

import { Button } from "../shadcn/button";

export function AlertToast() {
  return (
    <div className="flex flex-wrap gap-2">
      <Button
        variant="outline"
        onClick={() => toast.error("You must login to use this fiture!")}
      >
        Error
      </Button>
    </div>
  );
}
